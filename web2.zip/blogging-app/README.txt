Assignment: Creating a CRUD API with Node.js and MongoDB

Goal: Develop a fully functional CRUD API for simple blogging platforms using Node.js and MongoDB.

Requirements:

Setup and initialization:

Setting up a Node.js project using npm.
Initialize a new MongoDB database for your application.
API endpoints:

POST/Blogs: To create a new blog post.
GET /blogs: To retrieve all blog posts.
GET /blogs/:id: To retrieve one blog post by ID.
PUT /blogs/:id: To update a blog post by ID.
DELETE /blogs/:id: To delete a blog post by ID.
Database:

Use native MongoDB methods for operations on the underlying data (find, insertOne, updateOne, deleteOne, etc.).
Provide error handling and return responses and HTTP codes.
Each post must retain the title, text, author, and timestamps.
Check data:

Implement validation data to determine that all submitted blog posts contain a title and body.
Error processing:

Enable handling of database errors and invalid queries.
Testing:

Manually test the API using the Postman tool or write automated tests to ensure all endpoints are working as expected.
Not necessary:

Creating a simple interface:

Develop a simple interface to interact with your CRUD API for your blogging platform. This part of the assignment is optional and is intended to provide an opportunity to hone your full stack development skills.
Additional resources:

Node.js documentation: https://nodejs.org/en/docs/
MongoDB Documentation: https://docs.mongodb.com/manual/
Express.js: https://expressjs.com/
Mongoose: https://mongoosejs.com/
Beginning of work:

Clone this repository: git clone https://github.com/erasil111/ass3web.git
Go to project selection: cd blog-api-node-mongodb.
Specify depending on: npm install -y ,npm i express mongoose
Start the server: npm server.js
Open Postman or another API tool and test the endpoint API.