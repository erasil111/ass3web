/*document.addEventListener('DOMContentLoaded', () => {
    const blogForm = document.getElementById('blogForm');
    const blogsContainer = document.getElementById('blogs');
  
    fetchBlogs();
  
    blogForm.addEventListener('submit', (event) => {
      event.preventDefault();
      createBlog();
    });
  
    function fetchBlogs() {
      fetch('/blogs')
        .then(response => response.json())
        .then(blogs => displayBlogs(blogs))
        .catch(error => console.error('Error fetching blogs:', error));
    }
  
    function createBlog() {
      const title = document.getElementById('title').value;
      const body = document.getElementById('body').value;
      const author = document.getElementById('author').value;
  
      const blogData = {
        title,
        body,
        author
      };
  
      fetch('/blogs', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(blogData)
      })
        .then(response => response.json())
        .then(blog => {
          fetchBlogs(); 
          clearForm();  
        })
        .catch(error => console.error('Error creating blog:', error));
    }
  
    function displayBlogs(blogs) {
      blogsContainer.innerHTML = '';
  
      if (blogs.length === 0) {
        blogsContainer.innerHTML = '<p>No blogs available</p>';
      } else {
        blogs.forEach(blog => {
          const blogCard = createBlogCard(blog);
          blogsContainer.appendChild(blogCard);
        });
      }
    }
  
    function createBlogCard(blog) {
      const blogCard = document.createElement('div');
      blogCard.classList.add('card', 'mb-3');
  
      const cardBody = document.createElement('div');
      cardBody.classList.add('card-body');
  
      const title = document.createElement('h5');
      title.classList.add('card-title');
      title.textContent = blog.title;
  
      const body = document.createElement('p');
      body.classList.add('card-text');
      body.textContent = blog.body;
  
      const author = document.createElement('p');
      author.classList.add('card-text', 'text-muted');
      author.textContent = `Author: ${blog.author}`;
  
      cardBody.appendChild(title);
      cardBody.appendChild(body);
      cardBody.appendChild(author);
  
      blogCard.appendChild(cardBody);
  
      return blogCard;
    }
  
    function clearForm() {
      document.getElementById('title').value = '';
      document.getElementById('body').value = '';
      document.getElementById('author').value = '';
    }
  });
  */